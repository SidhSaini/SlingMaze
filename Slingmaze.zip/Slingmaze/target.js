class A extends Ground {
  constructor(x, y){
    super(x,y,50,50);
    this.visibility = 255
  }
  display(){
    super.display()
  }