const Engine = Matter.Engine;
const World= Matter.World;
const Bodies = Matter.Bodies;
const Constraint = Matter.Constraint;

var engine, world;
var base1,base2,base3,base4,base5;
var platform;
var bullet, slingShot;

function preload() {
    
}

function setup(){
    var canvas = createCanvas(1200,400);
    engine = Engine.create();
    world = engine.world;


    ground = new Ground(600,height,1200,20);
    platform = new Ground(150, 305, 300, 170);

    base1 = new Base(700,320,70,70);
    base2 = new Base(920,320,70,70);

    base3 = new Base(700,240,70,70);
    base4 = new Base(920,240,70,70);

    base5 = new Base(810,160,70,70);
    bullet = new bullet(200,50);
    //log6 = new Log(230,180,80, PI/2);
    slingshot = new Sling(bird.body,{x:200, y:50});
}

function draw(){
    background(backgroundImg);
    Engine.update(engine);
    //strokeWeight(4);
    base1.display();
    base2.display();
    ground.display();

    base3.display();
    base4.display();
    

    base5.display()

    bullet.display()
    //log6.display();
    slingshot.display();    
}

function mouseDragged(){
    Matter.Body.setPosition(bird.body, {x: mouseX , y: mouseY});
}


function mouseReleased(){
    slingshot.fly();
}

function keyPressed(){
    if(keyCode === 32){
        slingshot.attach(bird.body);
    }
}