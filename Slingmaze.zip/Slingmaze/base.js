class Base extends Ground{
  constructor(x, y, width, height){
    super(x,y,width,height);
  }

};
